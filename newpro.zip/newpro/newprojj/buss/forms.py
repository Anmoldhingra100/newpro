from django import forms
from .models import Pass

class PassForm(forms.ModelForm):
    class Meta:
        model = Pass
        fields = ['student', 'pass_type', 'issue_date', 'expiration_date']

class FareCalculationForm(forms.Form):
    Source = forms.CharField(max_length=100, label='Source')
    Destination = forms.CharField(max_length=100, label='Destination')


class DepotForm(forms.Form):
    depot_name = forms.CharField(label='Enter Bus Depot Name', max_length=255)



from django import forms
from .models import Complaint

class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ['firstname', 'lastname', 'location', 'phone', 'incidence', 'victim_name']


from django import forms
from .models import BusPass

class BusPassForm(forms.ModelForm):
    class Meta:
        model = BusPass
        fields = ['first_name', 'last_name', 'start_date', 'end_date', 'college', 'source', 'destination']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
            'college': forms.TextInput(attrs={'placeholder': 'Write N.A. for General Pass'}),
        }



